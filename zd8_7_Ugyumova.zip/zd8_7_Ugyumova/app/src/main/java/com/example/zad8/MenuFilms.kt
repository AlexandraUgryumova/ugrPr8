package com.example.zad8

import com.google.gson.Gson
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.graphics.drawable.toIcon
import androidx.core.net.toFile

class MenuFilms : AppCompatActivity() {
    private lateinit var filmList: ArrayList<Film>
    private lateinit var listView: ListView
    private val PICK_IMAGE_REQUEST = 1
    private var selectedImageUri: Uri? = null
    private lateinit var sortedFilmList: ArrayList<Film>
    private var selectedFilmPosition: Int = -1
    private lateinit var filteredFilmList: ArrayList<Film>
    private lateinit var originalFilmList: ArrayList<Film>
    private lateinit var filteredFilmAdapter: FilmAdapter
    private lateinit var originalFilmAdapter: FilmAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_films)

        originalFilmList = ArrayList()
        filteredFilmList = ArrayList()
        filmList = ArrayList()

        filmList.add(Film("До встречи с тобой", R.drawable.mov2, "Романтика/Драма", "Теа Шэррок", "Лу Кларк знает, сколько шагов от автобусной остановки до ее дома. Она знает, что ей очень нравится работа в кафе и что, скорее всего, она не любит своего бойфренда Патрика. Но Лу не знает, что вот-вот потеряет свою работу и что в ближайшем будущем ей понадобятся все силы, чтобы преодолеть свалившиеся на нее проблемы."))
        filmList.add(Film("Гарри Поттер и философский камень", R.drawable.mov1, "Фэнтези/Приключения", "Крис Коламбус", "Жизнь Гарри Поттера нельзя назвать сладкой: его родители умерли, а от дяди и тётки, взявших сироту на воспитание, достаются лишь тычки да подзатыльники. Но в одиннадцатый день рождения Гарри всё меняется. Странный гость, приносит письмо, из которого мальчик узнаёт, что на самом деле он чистокровный волшебник и принят в Хогвартс — школу магии."))
        filmList.add(Film("Круэлла", R.drawable.mov13, "Криминал/Комедийная драма", "Крейг Гиллеспи", "Лондон 70-х годов охвачен зарождающейся культурой панк-рока. Невероятно одаренная мошенница по имени Эстелла решает сделать себе имя в мире моды.  В один прекрасный день модное чутье Эстеллы привлекает внимание шикарной и пугающе высокомерной баронессы фон Хельман."))
        filmList.add(Film("Властелин колец: Братство Кольца", R.drawable.mov3, "Фэнтези/Приключения", "Питер Джексон", "Сказания о Средиземье — это хроника Великой войны за Кольцо, войны, длившейся не одну тысячу лет. Тот, кто владел Кольцом, получал власть над всеми живыми тварями, но был обязан служить злу."))
        filmList.add(Film("Пираты Карибского моря: На краю света", R.drawable.mov4, "Боевик/Приключения", "Гор Вербински", "Новые приключения Джека Воробья и его друзей Уилла Тернера и Элизабет Суонн. На этот раз Уиллу и Элизабет придется объединиться с самим Капитаном Барбоссой для того, чтобы отправиться на край света и спасти своего друга — Джека. Ситуация осложняется тем, что Элизабет попадает к сингапурским пиратам…"))
        filmList.add(Film("Призрак", R.drawable.mov5, "Комедия/Детский", "Александр Войтинский", "Юрий Гордеев — амбициозный авиаконструктор — был в шаге от своего триумфа. Но сегодня его никто не видит и не слышит, и конкурент по бизнесу беспрепятственно закрывает его компанию. Юра разбился в автокатастрофе и стал призраком. Семиклассник Ваня Кузнецов — единственный, кто его видит и может ему помочь."))
        filmList.add(Film("Великий Гэтсби", R.drawable.mov6, "Романтика/Драма", "Лурман, Баз", "«Великий Гэтсби» рассказан от лица как бы Фицджеральда, вероятного писателя Ника Каррауэйя, который весной 1922 года, в эпоху разлагающейся морали, блистательного джаза и «королей контрабандного алкоголя», приезжает со Среднего Запада в Нью-Йорк."))
        filmList.add(Film("Железный человек 3", R.drawable.mov7, "Боевик/Фантастика", "Шейн Блэк", "Тони Старк сталкивается с новым вызовом, когда его личная жизнь разрушается и его близкие подвергаются опасности. Он вынужден использовать все свои навыки и свою высокотехнологичную броню, чтобы защитить тех, кто ему дорог."))
        filmList.add(Film("Начало", R.drawable.mov8, "Боевик/Фантастика", "Кристофер Нолан", "Дом Кобб - опытный вор, специалист по краже секретов из снов подсознания. Он получает задание не украсть информацию, а посеять идею в сознании цели, используя метод \"начала\". Сможет ли он выполнить невозможную миссию?"))
        filmList.add(Film("История игрушек", R.drawable.mov14, "Прюключения", "Джон Лассетер", "В мире игрушек Анди, маленького мальчика, игрушки оживают и ведут свою собственную жизнь, когда никто не видит. История следует за приключениями Вуди, Базза и других игрушек, когда они сталкиваются с опасностями и находят свою настоящую ценность."))
        filmList.add(Film("Фантастические твари: Тайны Дамблдора", R.drawable.mov9, "Фэнтези/Приключения", "Дэвид Йейтс", "Профессор Альбус Дамблдор узнает, что могущественный темный волшебник Геллерт Грин-де-Вальд планирует захватить власть над миром. Понимая, что не сможет остановить его в одиночку, Дамблдор просит магозоолога Ньюта Саламандера возглавить команду из выдающихся волшебников и одного отважного магла-пекаря."))
        filmList.add(Film("Титаник", R.drawable.mov10, "Романтика/Драма", "Джеймс Кэмерон", "Пассажир нижней палубы Джек выиграл билет в карты, а богатая наследница Роза отправляется в Америку, чтобы выйти замуж по расчёту. Чувства молодых людей только успевают расцвести, и даже не классовые различия создадут испытания влюблённым, а айсберг, вставший на пути считавшегося непотопляемым лайнера."))
        filmList.add(Film("Назад в будущее", R.drawable.mov11, "Фантастика", "Роберт Земекис", "Марти Макфлай путешествует назад во времени на своем экспериментальном автомобиле времени и вступает в приключения с молодым версиями своих родителей. Он должен найти способ вернуться в настоящее время, прежде чем изменит будущее."))
        filmList.add(Film("Аватар", R.drawable.mov12, "Фантастика", "Джеймс Кэмерон", "На планете Пандора существует конфликт между людьми и местным народом Нави. Джейк Салли, бывший морской пехотинец, вступает в мир Нави, используя свое аватарское тело, и становится частью борьбы за выживание этого волшебного мира."))




        listView = findViewById(R.id.listView)
        originalFilmAdapter = FilmAdapter(this, filmList)
        listView.adapter = originalFilmAdapter
        sortedFilmList = ArrayList(filmList)
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedFilm = filmList[position]
            val intent = Intent(this, FilmDetailsActivity::class.java)
            intent.putExtra("film", selectedFilm)
            startActivity(intent)
            selectedFilmPosition=position
        }
    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_add -> {
                showAddFilmDialog()
                return true
            }
            R.id.menu_delete -> {
                if (selectedFilmPosition != -1) {
                    filmList.removeAt(selectedFilmPosition)
                    (listView.adapter as FilmAdapter).notifyDataSetChanged()
                    Toast.makeText(this, "Фильм удален", Toast.LENGTH_SHORT).show()
                    selectedFilmPosition=-1
                } else {
                    Toast.makeText(this, "Выберите фильм для удаления", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            R.id.menu_search -> {
                showSearchDialog()
                return true
            }
            R.id.menu_sort -> {

                return true
            }
            R.id.menu_show_all -> {
                showAllFilms()
                return true
            }
            else -> return super.onOptionsItemSelected(item)

        }
    }
    private fun showAllFilms() {
      recreate()
    }
    fun showMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.inflate(R.menu.menu_films)

        popupMenu.setOnMenuItemClickListener { item ->
            onOptionsItemSelected(item)
        }

        popupMenu.show()
    }
    private fun showAddFilmDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_add_film)
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)

        val etTitle = dialog.findViewById<EditText>(R.id.et_title)
        val etGenre = dialog.findViewById<EditText>(R.id.et_genre)
        val etAutoh = dialog.findViewById<EditText>(R.id.et_autor)
        val etOpsaine = dialog.findViewById<EditText>(R.id.et_sumary)
        val btnAdd = dialog.findViewById<Button>(R.id.btn_add)
        val btnAddPhoto = dialog.findViewById<Button>(R.id.btn_choose_photo)

        btnAddPhoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        btnAdd.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val genre = etGenre.text.toString().trim()
            val autor = etAutoh.text.toString().trim()
            val opsanie = etOpsaine.text.toString().trim()

            if (title.isNotEmpty() && genre.isNotEmpty()) {
                val newFilm = Film(title, R.drawable.nofoto, genre, autor, opsanie)
                filmList.add(newFilm)
                (listView.adapter as FilmAdapter).notifyDataSetChanged()
                Toast.makeText(this, "Фильм добавлен", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Введите название и жанр фильма, и выберите фотографию", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun showSearchDialog() {

        val searchDialog = Dialog(this)
        searchDialog.setContentView(R.layout.dialog_search)
        searchDialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)

        val etSearch = searchDialog.findViewById<EditText>(R.id.et_search)
        val btnSearch = searchDialog.findViewById<Button>(R.id.btn_search)

        btnSearch.setOnClickListener {
            val searchQuery = etSearch.text.toString().trim()
            filterFilmList(searchQuery)

            searchDialog.dismiss()
        }

        searchDialog.show()
    }

    private fun filterFilmList(searchQuery: String) {
        filteredFilmList.clear()

        for (film in filmList) {
            if (film.title.contains(searchQuery, ignoreCase = true)) {
                filteredFilmList.add(film)
            }
        }

        if (filteredFilmList.isNotEmpty()) {
            filteredFilmAdapter = FilmAdapter(this, filteredFilmList)
            listView.adapter = filteredFilmAdapter
            filteredFilmAdapter.notifyDataSetChanged()

            filmList= ArrayList(filteredFilmList)
        } else {
            listView.adapter = FilmAdapter(this, filmList)
            (listView.adapter as FilmAdapter).notifyDataSetChanged()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.data
        }
    }
}
